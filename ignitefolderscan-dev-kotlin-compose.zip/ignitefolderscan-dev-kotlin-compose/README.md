# Ignite Folder Tracking <img src="assets/images/icon.png" width="50px" style="border-radius:50px" />

An Android 10 application to inventory folders using RFID, a barcode scanning and a built-in camera. It can also use Geiger Search to hone in on a specific folder in the room. You can also pull up details of a folder including what color tabbings it should have.

1. [Developing](./docs/development.md)
2. [Building APK](./docs/build.md)
2. [Hardware Requirements](./docs/hardware.md)
3. [Hatting - English](./docs/hatting.md)
4. [Hatting - Spanish](./docs/hatting.md)