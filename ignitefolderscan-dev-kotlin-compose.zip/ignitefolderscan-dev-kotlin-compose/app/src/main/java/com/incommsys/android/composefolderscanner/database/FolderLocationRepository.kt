package com.leonell.android.composefolderscanner.database

import android.util.Log
import com.google.gson.Gson
import com.leonell.android.composefolderscanner.database.dao.FolderLocationDao
import com.leonell.android.composefolderscanner.database.model.FolderLocationEntity
import com.leonell.android.composefolderscanner.models.*
import com.leonell.android.composefolderscanner.services.FolderLocationsRestInterface
import com.leonell.android.composefolderscanner.services.WebApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import javax.inject.Inject

class FolderLocationRepository @Inject constructor(
   private val folderLocationsDao : FolderLocationDao
) : FolderLocationDao {
      private val webApi : FolderLocationsRestInterface = WebApi().getFolderLocationWebService()

      override fun getFolderLocationEntity(id: String): Flow<FolderLocationEntity> = folderLocationsDao.getFolderLocationEntity(id)
      override fun getFolderLocationEntities(): Flow<List<FolderLocationEntity>>  =  folderLocationsDao.getFolderLocationEntities()

      suspend fun getFolderLocationsREST() = withContext(Dispatchers.IO){
         try{
            val dbLocations = folderLocationsDao.getFolderLocationEntitiesSaved()
            if(dbLocations.none { it.custom == false }){
               Log.d("FolderLocationRepository", "Calling REST API for locations")
               val locations = webApi.getLocations().locations
               locations.map{it.original = it.name}
               folderLocationsDao.insertOrIgnoreFolderLocations(locations.map { it.asDatabaseModel()})
            } else {
               Log.d("FolderLocationRepository", "Already loaded db")
            }
         } catch (exception : Exception){
            Log.e("FolderLocationRepository", exception.stackTraceToString())
         }
      }
      //override fun getFolderLocationEntities(search: String): Flow<List<FolderLocationEntity>>  = folderLocationsDao.getFolderLocationEntities(search)

      override fun getFolderLocationEntitiesSaved(): List<FolderLocationEntity>  = folderLocationsDao.getFolderLocationEntitiesSaved()

      override suspend fun insertOrIgnoreFolderLocations(FolderLocationEntities: List<FolderLocationEntity>): List<Long>  = folderLocationsDao.insertOrIgnoreFolderLocations(FolderLocationEntities)

      /**
       * Updates [folder] in the db that match the primary key, and no-ops if they don't
       */
      override suspend fun updateFolderLocation(folder: FolderLocationEntity)  = folderLocationsDao.updateFolderLocation(folder)

      /**
       * Updates [entities] in the db that match the primary key, and no-ops if they don't
       */
      override suspend fun updateFolderLocations(entities: List<FolderLocationEntity>)  = folderLocationsDao.updateFolderLocations(entities)

      /**
       * Inserts or updates [entities] in the db under the specified primary keys
       */
      override suspend fun upsertFolderLocations(entities: List<FolderLocationEntity>)  = folderLocationsDao.upsertFolderLocations(entities)
      /**
       * Deletes rows in the db matching the specified [ids]
       */
      override suspend fun deleteFolderLocations(ids: List<String>) = folderLocationsDao.deleteFolderLocations(ids)

      fun lookup(aBarcode: ScanModel): BarcodeLookup? {
         val result = runCatching {
               webApi.resolveBarcode(aBarcode.barcodeId).execute().body()
         }

         if (result.isSuccess){
            val gson  = Gson()
            when (result.getOrNull()?.entityType){
               in setOf(FolderEntityType.LOCATION, FolderEntityType.SHELF, FolderEntityType.UNKNOWN)->{
                  result.getOrNull()?.entityObject = gson.fromJson(result.getOrNull()?.entity, BarcodeEntityModel.FolderLocation::class.java)
               }
                FolderEntityType.FOLDER -> {
                  result.getOrNull()?.entityObject = gson.fromJson(result.getOrNull()?.entity, BarcodeEntityModel.Person::class.java)
               } else -> {}
            }
         }
         return result.getOrNull()
      }
   fun logOneLocation(aBarcode: String, aLocationId : Long): Int  {
      return webApi.logProjectBarcode(aBarcode,aLocationId).execute().code()
   }
}