package com.leonell.android.composefolderscanner.ui.viewmodels
import android.content.Context
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.*
import com.leonell.android.composefolderscanner.database.LoggingQueueRepository
import com.leonell.android.composefolderscanner.models.BarcodeEntityModel
import com.leonell.android.composefolderscanner.models.ScanModel
import com.leonell.android.composefolderscanner.models.asLoggingQueueModel
import com.leonell.android.composefolderscanner.services.FolderLoggerWorkName
import com.leonell.android.composefolderscanner.services.FolderLoggerWorker
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.Duration
import java.util.stream.Collectors
import javax.inject.Inject


data class ScanUiState (
   val barcode : ScanModel? = null,
   val folders : MutableList<ScanModel> = mutableListOf(),
   val geigerFolders : MutableList<BarcodeEntityModel.Person> = mutableListOf(),
   var currentlyLogging : Int = 0
)

@HiltViewModel
class ScanViewModel @Inject constructor(
   private val loggingQueueRepo  : LoggingQueueRepository,
) : ViewModel(){
   private val mutableUiState = MutableStateFlow(ScanUiState())
   private val logging = mutableStateOf(false)
   val uiState : StateFlow<ScanUiState> = mutableUiState.asStateFlow()
   private var loggingJob: Job? = null

   fun getLoggingCount() : Flow<Int> = loggingQueueRepo.getLoggingQueueCount()
   fun clearBarcodes() {
      mutableUiState.update { currentState->
         currentState.copy(barcode = null, folders = mutableListOf())
      }
   }
   fun addGeiger(aPerson : BarcodeEntityModel.Person){
      mutableUiState.update { currentState->
         val gFolders = uiState.value.geigerFolders
         gFolders.add(0,aPerson)
         currentState.copy(geigerFolders = gFolders)
      }
   }
   fun setBarcodeScan(aBarcode : ScanModel){
      mutableUiState.update { currentState-> currentState.copy(barcode = aBarcode) }
   }

   fun logBarcode(aBarcode: ScanModel, context: Context) {
       //launch logger
      if (aBarcode.locationId != null) {
         viewModelScope.launch {
            if(aBarcode.barcodeId.toIntOrNull() != null){
               loggingQueueRepo.upsertLoggingQueueEntities(listOf(aBarcode.asLoggingQueueModel()))
            }
         }

         FolderLoggerWorker.initLogger(context)
      }
   }

   fun removeGeiger(id: Number) {
      mutableUiState.update { currentState ->
         currentState.copy(geigerFolders = uiState.value.geigerFolders.stream().filter { it.id != id }.collect(Collectors.toList()))
      }
   }

   fun clearGeiger() {
      mutableUiState.update { currentState->
         currentState.copy(geigerFolders = mutableListOf())
      }
   }

   fun clearBarcode() {
      mutableUiState.update { currentState->
         currentState.copy(barcode = null)
      }
   }

}