package com.leonell.android.composefolderscanner.ui.viewmodels
import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.leonell.android.composefolderscanner.models.BarcodeEntityModel
import com.leonell.android.composefolderscanner.services.WebApi
import com.leonell.android.composefolderscanner.services.PersonRestInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

private fun profileUiState(): ProfileUiState {
   return ProfileUiState.Ready
}

sealed interface ProfileUiState {
   data class Success(val person: BarcodeEntityModel.Person,
                      val staffAssignment: List<BarcodeEntityModel.StaffAssignment>) : ProfileUiState
   data class Error(val message : String) : ProfileUiState
   object Ready : ProfileUiState
   object Loading : ProfileUiState
}


class ProfileViewModel  : ViewModel(){
   var search by mutableStateOf("")
      private set

   private var mutableUiState = MutableStateFlow(profileUiState())
   val uiState : StateFlow<ProfileUiState> = mutableUiState.asStateFlow()
   private val webApi : PersonRestInterface = WebApi().getPersonWebService()

   val searchPerson : Flow< List<BarcodeEntityModel.Person>> =
      snapshotFlow{search}
         .debounce(500)
         .onEmpty { emptyList<BarcodeEntityModel>() }
         .mapLatest{webApi.searchPerson(search)}
         .catch { exception->
            print(exception.message)
         }
         .stateIn(
            viewModelScope,
            started = SharingStarted.Eagerly,
            initialValue = emptyList()
         )
    fun getPerson(barcodeId : String?, associateId : String?) {
       viewModelScope.launch(Dispatchers.IO){
          try {
             mutableUiState.update { ProfileUiState.Loading }
             var person  :  BarcodeEntityModel.Person? = null

             if (barcodeId != null){
                person = webApi.getPersonByBarcode(barcodeId)
             } else if (associateId != null ) {
                person = webApi.getPersonByAssociateId(associateId)
             }

             if(person?.id != null ){
                val staffAssignments = webApi.getAssignedStaff(person.id!!)
                mutableUiState.update { ProfileUiState.Success(person, staffAssignments) }
             }
          } catch(myException : Exception) {
             Log.e("ProfileViewModel",myException.stackTraceToString())
             mutableUiState.update { ProfileUiState.Error(message = "Couldn't retrieve the profile...") }
          }
       }
    }
   fun updateSearch(name : String){
      search = name
   }

}