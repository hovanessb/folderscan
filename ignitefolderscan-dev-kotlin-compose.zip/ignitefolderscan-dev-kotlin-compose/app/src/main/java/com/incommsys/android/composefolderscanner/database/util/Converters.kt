/*
 * Copyright 2022 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.leonell.android.composefolderscanner.database.util

import androidx.room.TypeConverter
import com.leonell.android.composefolderscanner.models.FolderEntityType
import kotlinx.datetime.Instant

class InstantConverter {
    @TypeConverter
    fun longToInstant(value: Long?): Instant? =
        value?.let(Instant::fromEpochMilliseconds)

    @TypeConverter
    fun instantToLong(instant: Instant?): Long? =
        instant?.toEpochMilliseconds()
}

class FolderEntityTypeConverter {
    @TypeConverter
    fun stringToFolderEntityType(value: String?): FolderEntityType {
        return when (value){
            "FOLDER"->FolderEntityType.FOLDER
            "LOCATION"->FolderEntityType.LOCATION
            "SHELF"->FolderEntityType.SHELF
            else -> FolderEntityType.UNKNOWN
        }
    }

    @TypeConverter
    fun folderEntityTypeToString(type: FolderEntityType?): String {
        return when (type){
            FolderEntityType.FOLDER->"FOLDER"
            FolderEntityType.LOCATION->"LOCATION"
            FolderEntityType.SHELF->"SHELF"
            else -> "UNKNOWN"
        }
    }
}