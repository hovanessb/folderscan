package com.leonell.android.composefolderscanner

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

/*
@HiltViewModel
class MainActivityViewModel @Inject constructor(
   userDataRepository: UserDataRepository
) : ViewModel() {
   var uiState: StateFlow<MainActivityUiState> = userDataRepository.userData.map { it ->
      Success(it)
   }.stateIn(
      scope = viewModelScope,
      initialValue = Loading,
      started = SharingStarted.WhileSubscribed(5_000)
   )
}

sealed interface MainActivityUiState {
   object Loading : MainActivityUiState
   data class Success(val userData: UserData) : MainActivityUiState
}
*/