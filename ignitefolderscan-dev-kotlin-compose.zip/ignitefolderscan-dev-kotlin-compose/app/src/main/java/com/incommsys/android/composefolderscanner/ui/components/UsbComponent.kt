package com.leonell.android.composefolderscanner.ui.components

import android.content.Context
import android.content.res.Configuration
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.view.KeyEvent
import android.view.View
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp


@Composable
internal fun UsbComponent() {
   val barcodeBuffer = remember { StringBuilder() }
   // Use a Compose Column to arrange your UI components
   Column(
      modifier = Modifier
         .fillMaxSize()
         .padding(16.dp)
   ) {
      // Text to display barcode scans
      Text(
         text = "Scanned Barcode: ${barcodeBuffer.toString()}",
         modifier = Modifier.padding(8.dp),
         style = MaterialTheme.typography.bodyMedium
      )

      // Call the combined USB and barcode scanning logic
      UsbAndBarcodeScannerLogic(barcodeBuffer)
   }
}

@Composable
private fun UsbAndBarcodeScannerLogic(barcodeBuffer: StringBuilder) {
   // Get the USB manager service
   val usbManager = LocalConfiguration.current.keyboard

   // Check if any keyboard is attached
   if (usbManager != Configuration.KEYBOARD_NOKEYS) {
      // Intercept barcode scans using KeyEvent.Callback
      InterceptBarcodeScans(barcodeBuffer)
   }
}

private fun isInterestingDevice(usbDevice: UsbDevice): Boolean {
   // Implement your logic to determine if the USB device is of interest
   // For example, check device/vendor ID, product ID, etc.
   // Modify this based on the specifics of your USB barcode scanner
   return true
}

private fun displayDeviceInfo(usbDevice: UsbDevice) {
   // Display information about the connected USB device
   val deviceInfo = "Device Name: ${usbDevice.deviceName}\n" +
         "Device ID: ${usbDevice.deviceId}\n" +
         "Vendor ID: ${usbDevice.vendorId}\n" +
         "Product ID: ${usbDevice.productId}"

   // Update UI or perform other actions with the device information
   // For example, you might show a message or enable certain functionality
   println(deviceInfo)
}

@Composable
private fun InterceptBarcodeScans(barcodeBuffer: StringBuilder) {
   val view = LocalView.current
   DisposableEffect(view) {
      val callback = object : KeyEvent.Callback {
         override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
            // Handle key down events
            handleBarcodeInput(barcodeBuffer, event?.keyCode)
            return true
         }

         override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
            // Handle key up events if needed
            return true
         }

         override fun onKeyMultiple(p0: Int, p1: Int, p2: KeyEvent?): Boolean {
            TODO("Not yet implemented")
         }

         override fun onKeyLongPress(keyCode: Int, event: KeyEvent?): Boolean {
            // Handle long press events if needed
            return true
         }
      }

      val keyListener = View.OnKeyListener { _, keyCode, event ->
         callback.onKeyDown(keyCode, event)
      }

      view.setOnKeyListener(keyListener)

      onDispose {
         view.setOnKeyListener(null)
      }
   }

   // If using Android Compose UI, you can include UI components here as needed
   // For example, you can have a TextField to display the barcode scans
   // or customize the UI based on barcode scanning events
}

private fun handleBarcodeInput(barcodeBuffer: StringBuilder, keyCode: Int?) {
   // Check if the keyCode corresponds to a valid barcode character
   if (keyCode in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 || keyCode == KeyEvent.KEYCODE_ENTER) {
      // Append the character to your barcode buffer
      // For example, use a StringBuilder to accumulate characters until an Enter key is pressed
      if (keyCode == KeyEvent.KEYCODE_ENTER) {
         val barcodeValue = barcodeBuffer.toString()
         // Process the barcode value (e.g., send it to your server or perform some action)
         processBarcode(barcodeValue)
         // Clear the buffer for the next scan
         barcodeBuffer.clear()
      } else {
         if (keyCode != null) {
            barcodeBuffer.append(('0'.code + (keyCode - KeyEvent.KEYCODE_0)).toChar())
         }
      }
   }
}

private fun processBarcode(barcodeValue: String) {
   // Implement your logic to handle the barcode value
   // This could involve sending it to a server, updating UI, etc.
   // For now, let's just print it
   println("Barcode Scanned: $barcodeValue")
}

