package com.leonell.android.composefolderscanner.services

import java.util.*

val SERVICE_UUID: UUID = UUID.fromString("00009800-0000-1000-8000-00805f9b34fb")
val STREAM_IN_UUID: UUID = UUID.fromString("00009901-0000-1000-8000-00805f9b34fb")
val STREAM_OUT_UUID: UUID = UUID.fromString("00009900-0000-1000-8000-00805f9b34fb")
const val FolderLoggerWorkName = "com.leonell.android.composefolderscanner.services.FolderLoggerWorker"
const val dBuV_dBm: Float = 74F
const val YES : String = "Y"

