package com.leonell.android.composefolderscanner.ui.viewmodels

import android.content.Context
import android.hardware.SensorManager
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.leonell.android.composefolderscanner.database.SensorDataRepository
import com.leonell.android.composefolderscanner.models.ScanModel
import com.leonell.android.composefolderscanner.models.SensorData
import com.leonell.android.composefolderscanner.models.asSensorDataEntity
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

@HiltViewModel
class TriangulationViewModel @Inject constructor(
   private val sensorDataRepo : SensorDataRepository
) : ViewModel() {

   private var sensorManager: SensorManager? =  null
   val sensorData =  MutableStateFlow<SensorData?>(null)
   suspend fun getSenses(app: Context) = withContext(Dispatchers.Main){
      sensorManager  = app.getSystemService(Context.SENSOR_SERVICE) as SensorManager
      sensorDataRepo.setSensorManager(sensorManager!!)
      viewModelScope.launch {
         sensorDataRepo.getAccelerometerDataFlow().collect { data ->sensorData.value = data}
      }
   }


   override fun onCleared() {
      super.onCleared()
   }

   fun saveRfidSensorData(sensorData: SensorData, rfidData: ScanModel) {
      sensorData.rssi = rfidData.rssi
      sensorData.phase = rfidData.phase
      viewModelScope.launch {
         sensorDataRepo.upsertSensorEntities(listOf(sensorData.asSensorDataEntity()))
      }
   }
   fun resetSensorData(){
      sensorDataRepo.resetSensorHistory()
   }

   fun deleteSessions() {
      viewModelScope.launch {
         sensorDataRepo.deleteSessions()
      }
   }

}