package com.leonell.android.composefolderscanner.ui

import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.runtime.*
import androidx.navigation.*
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.composable
import androidx.compose.ui.util.trace
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.leonell.android.composefolderscanner.ui.viewmodels.ConvergenceHandgunViewModel
import com.leonell.android.composefolderscanner.services.NetworkMonitor
import com.leonell.android.composefolderscanner.services.Navigation
import com.leonell.android.composefolderscanner.ui.screens.*
import com.leonell.android.composefolderscanner.ui.screens.DeviceRoute
import com.leonell.android.composefolderscanner.ui.screens.ProfileRoute
import com.leonell.android.composefolderscanner.ui.screens.ScanRoute
import com.leonell.android.composefolderscanner.ui.viewmodels.ScanViewModel
import com.leonell.android.composefolderscanner.ui.viewmodels.TriangulationViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

@Composable
fun rememberFolderAppState(
   networkMonitor: NetworkMonitor,
   coroutineScope: CoroutineScope = rememberCoroutineScope(),
   navController: NavHostController = rememberNavController()
): FolderAppState {
   return remember(navController, coroutineScope, networkMonitor) {
      FolderAppState(navController, coroutineScope, networkMonitor)
   }
}

@Stable
class FolderAppState(
   val navController: NavHostController,
   coroutineScope: CoroutineScope,
   networkMonitor : NetworkMonitor
) {
   val currentDestination: NavDestination?
      @Composable get() = navController
         .currentBackStackEntryAsState().value?.destination

   val isOffline = networkMonitor.isOnline
      .map(Boolean::not)
      .stateIn(
         scope = coroutineScope,
         started = SharingStarted.WhileSubscribed(5_000),
         initialValue = false
      )

   /**
    * Map of top level destinations to be used in the TopBar, BottomBar and NavRail. The key is the
    * route.
    */
   val navigations: List<Navigation> = Navigation.entries

   /**
    * UI logic for navigating to a top level destination in the app. Top level destinations have
    * only one copy of the destination of the back stack, and save and restore state whenever you
    * navigate to and from it.
    *
    * @param navigation: The destination the app needs to navigate to.
    */
   fun navigateToTopLevelDestination(navigation: Navigation) {
      trace("Navigation: ${navigation.name}") {
         val topLevelNavOptions = navOptions {
            // Pop up to the start destination of the graph to
            // avoid building up a large stack of destinations
            // on the back stack as users select items
            popUpTo(navController.graph.findStartDestination().id) {
               saveState = true
            }
            // Avoid multiple copies of the same destination when
            // reselecting the same item
            launchSingleTop = true
            // Restore state when reselecting a previously selected item
            restoreState = true
         }

         when (navigation) {
            Navigation.PROFILE -> navController.navigateToProfile(topLevelNavOptions)
            Navigation.SCAN -> navController.navigateToScan(topLevelNavOptions)
            Navigation.LOCATE -> navController.navigateToLocate("",topLevelNavOptions)
            Navigation.WRITE -> navController.navigateToWrite(topLevelNavOptions)
            Navigation.DEVICES -> navController.navigateToDevice(topLevelNavOptions)
         }
      }
   }

   fun onBackClick() {
      navController.popBackStack()
   }

}

const val profileNavigationRoute = "profile_route"
const val deviceNavigationRoute = "device_route"
const val scanNavigationRoute = "scan_route"
const val writeNavigationRoute = "write_route"
const val locateNavigationRoute = "locate_route"

fun NavController.navigateToProfile(navOptions: NavOptions? = null) {
   this.navigate(profileNavigationRoute, navOptions)
}

fun NavController.navigateToWrite(navOptions: NavOptions? = null) {
   this.navigate(writeNavigationRoute, navOptions)
}
fun NavController.navigateToScan(navOptions: NavOptions? = null) {
   this.navigate(scanNavigationRoute, navOptions)
}

fun NavController.navigateToLocate(barcodeId: String? = "", navOptions: NavOptions? = null) {
   this.navigate("${locateNavigationRoute}/{$barcodeId}", navOptions)
}

fun NavController.navigateToDevice(navOptions: NavOptions? = null) {
   this.navigate(deviceNavigationRoute, navOptions)
}

fun NavGraphBuilder.profileScreen(navController: NavController, scanModel : ScanViewModel) {
   composable(route = profileNavigationRoute) {
      ProfileRoute(navController = navController, scanModel = scanModel)
   }
}
fun NavGraphBuilder.deviceScreen(convergenceModel : ConvergenceHandgunViewModel) {
   composable(route = deviceNavigationRoute) {
      DeviceRoute(convergenceModel=convergenceModel)
   }
}

fun NavGraphBuilder.locateScreen(scanModel : ScanViewModel, convergenceModel: ConvergenceHandgunViewModel, triangulationViewModel: TriangulationViewModel) {
   composable(route = "${locateNavigationRoute}/{barcodeIdSeries}",
            arguments=listOf(navArgument("barcodeIdSeries"){type= NavType.StringType})) {
      LocateRoute(
         it.arguments?.getString("barcodeIdSeries")?.replace("}","")?.replace("{",""),
         scanModel = scanModel,convergenceModel=convergenceModel,triangulationModel=triangulationViewModel)
   }
}
@OptIn(ExperimentalAnimationApi::class)
fun NavGraphBuilder.writeScreen(scanModel : ScanViewModel, convergenceModel: ConvergenceHandgunViewModel) {
   composable(route = writeNavigationRoute) {
      WriteRoute(scanModel = scanModel,convergenceModel=convergenceModel)
   }
}

fun NavGraphBuilder.scanScreen(scanModel : ScanViewModel,convergenceModel: ConvergenceHandgunViewModel) {
   composable(route = scanNavigationRoute) {
      ScanRoute(scanModel = scanModel,convergenceModel=convergenceModel)
   }
}


