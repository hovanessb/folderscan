package com.leonell.android.composefolderscanner.ui.screens

import android.os.Build
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import androidx.annotation.RequiresApi
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.nativeKeyCode
import androidx.compose.ui.input.key.onInterceptKeyBeforeSoftKeyboard
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.style.TextOverflow
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.work.WorkInfo
import androidx.work.WorkManager
import com.leonell.android.composefolderscanner.models.BarcodeEntityModel
import com.leonell.android.composefolderscanner.models.ScanModel
import com.leonell.android.composefolderscanner.services.FolderIcons
import com.leonell.android.composefolderscanner.services.FolderLoggerWorkName
import com.leonell.android.composefolderscanner.ui.components.Barcodes
import com.leonell.android.composefolderscanner.ui.components.FolderLoadingWheel
import com.leonell.android.composefolderscanner.ui.components.LocationHeader
import com.leonell.android.composefolderscanner.ui.components.SelectLocations
import com.leonell.android.composefolderscanner.ui.viewmodels.ConvergenceHandgunState
import com.leonell.android.composefolderscanner.ui.viewmodels.ConvergenceHandgunViewModel
import com.leonell.android.composefolderscanner.ui.viewmodels.FolderLocationViewModel
import com.leonell.android.composefolderscanner.ui.viewmodels.ScanViewModel

@RequiresApi(Build.VERSION_CODES.O_MR1)
@Composable
internal fun ScanRoute(
   scanModel: ScanViewModel = hiltViewModel(),
   folderLocationModel: FolderLocationViewModel = hiltViewModel(),
   convergenceModel: ConvergenceHandgunViewModel = hiltViewModel()
) {
   ScanScreen(folderLocationModel = folderLocationModel, scanModel=scanModel, convergenceModel=convergenceModel)
}

@OptIn(ExperimentalComposeUiApi::class)
@RequiresApi(Build.VERSION_CODES.O_MR1)
@Composable
internal fun ScanScreen(
   folderLocationModel: FolderLocationViewModel ,
   scanModel: ScanViewModel,
   convergenceModel : ConvergenceHandgunViewModel
) {
   val snackbarHostState = remember { SnackbarHostState() }
   val folderLocationsState by folderLocationModel.uiState.collectAsStateWithLifecycle()
   val currentLocationUiState by folderLocationModel.currentLocationState.collectAsStateWithLifecycle()
   val tabState = remember { mutableIntStateOf(0) }
   val logged = remember { mutableIntStateOf(0) }
   val titles = listOf("Scan", "Locations")
   val barcodeData by scanModel.uiState.collectAsStateWithLifecycle()
   val connectedGun by convergenceModel.uiState.collectAsStateWithLifecycle()
   val folderLocations by folderLocationModel.getLocations.collectAsStateWithLifecycle(initialValue = listOf(), lifecycle = LocalLifecycleOwner.current.lifecycle)
   val folderLocation : BarcodeEntityModel.FolderLocation? =  currentLocationUiState.location
   val view = LocalView.current
   // only pickup RFIDs with tag data including folder series numbers
   // program later to filter out other types of folders
   val rfidFilter = remember { mutableListOf(10L,11L)}
   val openDialog = remember { mutableStateOf(false) }
   val keyboardBarcodeBuffer = remember { mutableStateOf("") }
   val listState = rememberLazyListState()
   //scanModel.logBarcode(ScanModel(0L,"000101090903",0.0F,locationId="0"), LocalContext.current)
   //scanModel.logBarcode(ScanModel(0L,"000100191751",0.0F,locationId="0"), LocalContext.current)
   //scanModel.logBarcode(ScanModel(0L,"000100668211",0.0F,locationId="0"), LocalContext.current)
   //scanModel.logBarcode(ScanModel(0L,"000100220462",0.0F,locationId="0"), LocalContext.current)
   LaunchedEffect(key1 = barcodeData.folders.size){
      listState.scrollToItem(0)
   }

   when(connectedGun){
      is ConvergenceHandgunState.Scanning -> if ((connectedGun as ConvergenceHandgunState.Scanning).rfidData != null){
         val rfidData = (connectedGun as ConvergenceHandgunState.Scanning).rfidData
         if(rfidData?.rawRead != null){
            if (barcodeData.folders.stream().noneMatch { rfidData.barcodeId == it.barcodeId }
                && rfidData.seriesId in rfidFilter
                && rfidData.barcodeId.length >= 12) {
               if (folderLocation != null) {
                     rfidData.locationId = folderLocation.id.toString()
                     scanModel.setBarcodeScan(rfidData)
                     logged.intValue =barcodeData.folders.size
                     view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_PRESS)
               }
            }
         }
      } else -> { }
   }

   /*
    Detect device barcode scans and set location
   */
   if (barcodeData.barcode != null
       && barcodeData.barcode!!.barcodeId.length >= 12) {
      if (tabState.intValue == 1 || barcodeData.barcode!!.barcodeId.startsWith("2") || barcodeData.barcode!!.barcodeId.startsWith("1")){
         folderLocationModel.lookup(barcodeData.barcode!!)
         if (folderLocation != null) {
           folderLocationModel.setLocation(folderLocation)
           if(!openDialog.value) {
               tabState.intValue = 0
               scanModel.clearBarcodes()
               logged.intValue = barcodeData.folders.size
            }
         }
      } else if (barcodeData.folders.stream().noneMatch{ barcodeData.barcode!!.barcodeId == it.barcodeId }){
         if (folderLocation != null) {
            view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_PRESS)
            barcodeData.barcode!!.locationId = folderLocation.id.toString()
            barcodeData.folders.add(0, barcodeData.barcode!!)
            scanModel.logBarcode(barcodeData.barcode!!, LocalContext.current)
            logged.intValue = barcodeData.folders.size
         } else {
            LaunchedEffect(key1 = barcodeData.barcode?.barcodeId) {
               snackbarHostState.showSnackbar( message = "No scanning location currently selected.", duration = SnackbarDuration.Short)
            }
         }
      }
   }

   WorkManager.getInstance(LocalContext.current)
      .getWorkInfosByTagLiveData(FolderLoggerWorkName)
      .observe(LocalLifecycleOwner.current){ workInfo: List<WorkInfo>? ->
         workInfo?.stream()?.filter{ it.state ==  WorkInfo.State.SUCCEEDED}
               ?.forEach{ finished->barcodeData.folders.stream().filter {
                  it.barcodeId == finished.outputData.getString("barcodeId") && !it.logged.value
               }.forEach{
                  it.logged.value = true
               }
            }
      }

   Column(modifier=Modifier.onInterceptKeyBeforeSoftKeyboard { keyCode->
      if( keyCode.type == KeyEventType.KeyUp){
         if (keyCode.nativeKeyEvent.keyCode in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9) {
            keyboardBarcodeBuffer.value += KeyEvent.keyCodeToString(keyCode.key.nativeKeyCode).split("_")[1].toInt()
         } else if(keyCode.key == Key.Enter) {
            if(keyboardBarcodeBuffer.value.isNotEmpty()){
               if(keyboardBarcodeBuffer.value.startsWith("2") || keyboardBarcodeBuffer.value.startsWith("1")){
                  val usbScanFolder = ScanModel(barcodeId = keyboardBarcodeBuffer.value)
                  folderLocationModel.lookup(usbScanFolder)
                  if (folderLocation != null) {
                     folderLocationModel.setLocation(folderLocation)
                     if(!openDialog.value) {
                        tabState.intValue = 0
                        scanModel.clearBarcodes()
                        logged.intValue = barcodeData.folders.size
                     }
                  }
               } else {
                  if (barcodeData.folders.stream().noneMatch{ keyboardBarcodeBuffer.value == it.barcodeId } && keyCode.key == Key.Enter){
                     if (folderLocation != null) {
                        val usbScanFolder = ScanModel(barcodeId = keyboardBarcodeBuffer.value, locationId = folderLocation.id.toString())
                        view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_PRESS)
                        barcodeData.barcode?.locationId = folderLocation.id.toString()
                        barcodeData.folders.add(0,  usbScanFolder)
                        scanModel.logBarcode(usbScanFolder, view.context)
                        logged.intValue = barcodeData.folders.size
                     }
                  }
               }
               keyboardBarcodeBuffer.value = ""
            }
         }
      }
      false
   }) {
      TabRow(selectedTabIndex = tabState.intValue) {
         titles.forEachIndexed { index, title ->
            Tab(
               selected = tabState.intValue == index,
               onClick = { tabState.intValue = index},
               text = { Text(text = title, maxLines = 2, overflow = TextOverflow.Ellipsis) }
            )
         }
      }

      AnimatedContent(targetState = tabState.intValue,
                      transitionSpec = {
                         if(tabState.intValue > 0){
                            slideInHorizontally{width -> width} togetherWith slideOutHorizontally { width-> -width }
                         } else {
                            slideInHorizontally{width -> -width} togetherWith slideOutHorizontally { width-> width }
                      }}, label = ""
      ) { myState ->
         when(myState){
            0 -> {

               Column(
                  modifier = Modifier
                     .fillMaxSize()
                     ,
                  horizontalAlignment = Alignment.CenterHorizontally
               ) {
                  Scaffold(floatingActionButton = {
                        if(barcodeData.folders.isNotEmpty() || connectedGun is ConvergenceHandgunState.Scanning || connectedGun is ConvergenceHandgunState.Busy){
                              //todo Add filter for other types of folders
                              FloatingActionButton(onClick = {
                              //scanModel.addBarcode(BarcodeScan(UUID.randomUUID().toString()))
                              scanModel.clearBarcodes()
                              logged.intValue = 0
                        }) {
                              AnimatedContent(targetState = connectedGun, label = "ANIMATEDSEARCH") { myGunState ->
                                 when(myGunState) {
                                    is ConvergenceHandgunState.Busy -> {
                                       FolderLoadingWheel(contentDesc = "busy...")
                                    }
                                    is ConvergenceHandgunState.Scanning -> {
                                       Text(text = "Scanning!")
                                    } else ->{
                                       Icon(FolderIcons.DELETE, "Delete")
                                    }
                                 }
                              }
                           }
                        }
                     },
                     snackbarHost = { SnackbarHost(snackbarHostState) }) { it ->
                     Column(
                        modifier = Modifier
                           .fillMaxSize()
                           .padding(it),
                        horizontalAlignment = Alignment.CenterHorizontally
                     ) {
                        LocationHeader(currentLocationUiState, logged.intValue.toString())
                        //UsbComponent()
                        Barcodes(barcodeList = barcodeData.folders, "SCAN A BARCODE", listState)
                     }
                  }
               }
            }
            1 -> {
               SelectLocations(  folderLocationsState ,
                                 folderLocationModel,
                                 openDialog,
                                 snackbarHostState,
                                 folderLocations,
                                 currentLocationUiState,
                                 tabState,
                                 scanModel,
                                 folderLocation)
            }
         }
      }
   }
}

