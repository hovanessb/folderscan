package com.leonell.android.composefolderscanner.services

import android.util.Log
import com.google.gson.GsonBuilder
import com.leonell.android.composefolderscanner.models.*
import com.leonell.android.composefolderscanner.ui.BASEURL
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Query
import retrofit2.http.Path
import java.io.IOException


interface PersonRestInterface  {
   @Headers(currentAuthToken,"Accept: Application/json")
   @GET("/leonell/server/folder/profile")
   suspend fun getPersonByBarcode (@Query("folderBarcodeId")  aBarcodeId : String) : BarcodeEntityModel.Person
   @Headers(currentAuthToken,"Accept: Application/json")
   @GET("/leonell/server/folder/profile")
   suspend fun getPersonByAssociateId (@Query("associateId")  aAssociateId: String) : BarcodeEntityModel.Person
   @Headers(currentAuthToken,"Accept: Application/json")
   @GET("/leonell/server/proc/assignment/{aAssociateId}")
   suspend fun getAssignedStaff (@Path("aAssociateId") aAssociateId: Number) : List<BarcodeEntityModel.StaffAssignment>
   @Headers(currentAuthToken,"Accept: Application/json")
   @GET("/leonell/server/search/v2/person/json")
   suspend fun searchPerson (@Query("query") aName: String) : List<BarcodeEntityModel.Person>

}


interface FolderLocationsRestInterface  {

   @Headers(currentAuthToken,
            "Accept: Application/json")
   @GET("/leonell/server/api/folder/locations")
   suspend fun getLocations () : Locations

   @Headers(currentAuthToken,
            "Accept: Application/json")
   @GET("/leonell/server/api/folder/log-location")
   fun logBarcode (@Query("barcodes") aBarcodeId:String, @Query("location") aLocationId: Number) : Call<SuccessModel>
   @Headers(projectAuthToken,
            "Accept: Application/json")
   @GET("/leonell/server/api/folder/log-location")
   fun logProjectBarcode (@Query("barcodes") aBarcodeId:String, @Query("location") aLocationId: Number) : Call<SuccessModel>

   @Headers(currentAuthToken,
      "Accept: Application/json")
   @GET("/leonell/server/folder/resolve")
   fun resolveBarcode (@Query("barcode") aBarcodeId: String) : Call<BarcodeLookup>

}



class WebApi {
   private val personService : PersonRestInterface
   private  val folderLocationService : FolderLocationsRestInterface

   init {
      val client = OkHttpClient.Builder().addInterceptor(
         object : Interceptor {
            @Throws(IOException::class)
            override fun intercept(chain: Interceptor.Chain): Response {
               val request: Request = chain.request()
               val response: Response = chain.proceed(request)

               if (response.code != 200) {
                  Log.e("WebAPI","Error code: ${response.code}")
                  Log.e("WebAPI", response.body.toString())
                  return response
               }
               return response
            }
         }
      )
      val gson = GsonBuilder()
         .serializeNulls()
         .setLenient()
         .create()

      val retrofit = Retrofit
         .Builder()
         .baseUrl(BASEURL)
         .addConverterFactory(GsonConverterFactory.create(gson))
         .client(client.build())
         .build()

      personService = retrofit.create(PersonRestInterface::class.java)
      folderLocationService = retrofit.create(FolderLocationsRestInterface::class.java)
   }

   fun getPersonWebService () : PersonRestInterface {
      return personService
   }

   fun getFolderLocationWebService () : FolderLocationsRestInterface {
      return folderLocationService
   }


}