package com.leonell.android.composefolderscanner.models

import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import com.leonell.android.composefolderscanner.database.model.LoggingQueueEntity
/*
|series_id|name|
|--|-----------|
|0 |       Solo|
|1 |    Audited|
|2 |    Student|
|3 |     Ethics|
|4 |  Personnel|
|10|        CF |
|11| CF (Div 6)|
|20|Audited - Staging|
*/
interface BarcodeEvent {
   val id: Long?
   val rawRead : ByteArray?
   val barcodeId : String
   val phase : Float
   val seriesId : Long?
   val rssi : Float
   val locationId : String?
   val logged : MutableState<Boolean>
}

class ScanModel(
   override val id: Long? = null,
   override val rawRead: ByteArray? = null,
   override val barcodeId: String = "",
   override val phase: Float = 0.0F,
   override val seriesId: Long? = -1,
   override var rssi: Float = 0.0F,
   override var logged: MutableState<Boolean> = mutableStateOf(false),
   override var locationId: String? = null
) : BarcodeEvent


fun ScanModel.asLoggingQueueModel() =
      LoggingQueueEntity(
         id= barcodeId.toLong(),
         barcodeId = barcodeId,
         locationId = locationId!!,
         rawRead= ""
      )
