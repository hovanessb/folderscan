package com.leonell.android.composefolderscanner

import android.app.Application
import android.util.Log
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.Configuration
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.decode.SvgDecoder
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject

@HiltAndroidApp
class MainApplication : Application(), ImageLoaderFactory , Configuration.Provider {

   @Inject
   lateinit var workerFactory: HiltWorkerFactory


   /**
    * Since we're displaying SVGs in the app, Coil needs an ImageLoader which supports this
    * format. During Coil's initialization it will call `applicationContext.newImageLoader()` to
    * obtain an ImageLoader.
    *
    * @see https://github.com/coil-kt/coil/blob/main/coil-singleton/src/main/java/coil/Coil.kt#L63
    */
   override fun newImageLoader(): ImageLoader {
      return ImageLoader.Builder(this)
         .components {
            add(SvgDecoder.Factory())
         }
         .build()
   }

   override val workManagerConfiguration: Configuration
      get() = Configuration.Builder()
         .setWorkerFactory(workerFactory)
         .setMinimumLoggingLevel(Log.DEBUG)
         .build()


}
