package com.leonell.android.composefolderscanner.services

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.leonell.android.composefolderscanner.database.LoggingQueueRepository
import com.leonell.android.composefolderscanner.database.model.asExternalModel
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import java.util.concurrent.TimeUnit
import java.util.stream.Collectors

@HiltWorker
class FolderLoggerWorker @AssistedInject constructor(
   @Assisted context: Context,
   @Assisted params: WorkerParameters,
   private val loggingQueueRepo : LoggingQueueRepository) : CoroutineWorker(context, params) {
   companion object {
      fun initLogger(context: Context) {
         WorkManager.getInstance(context).enqueueUniqueWork(
            FolderLoggerWorkName,
            ExistingWorkPolicy.REPLACE,
            OneTimeWorkRequestBuilder<FolderLoggerWorker>()
               .setInitialDelay(duration = 10,TimeUnit.SECONDS)
               .build()
         )
      }
   }
   override suspend fun doWork(): Result {
      val webApi: FolderLocationsRestInterface = WebApi().getFolderLocationWebService()
      var data : Result = Result.failure()
      loggingQueueRepo.getLoggingQueueEntitiesPost()
         .map{i -> i.asExternalModel() }
         .groupBy { it.locationId }
         .map{ it.value}
         .forEach{ groupOfLocations->
               groupOfLocations
               .chunked(20)
               .forEach { twentyBatch ->
                  try {
                     val barcodeCsv = twentyBatch.stream()
                        .map { txz -> txz.barcodeId }
                        .distinct()
                        .collect(Collectors.joining(","))

                     val resultApi = runCatching {
                        //println(barcodeCsv)
                        webApi.logBarcode(barcodeCsv, twentyBatch[0].locationId!!.toLong()) .execute()
                     }

                     data =
                        if (resultApi.getOrNull()?.isSuccessful == true && resultApi.getOrNull()?.code() == 200) {
                           loggingQueueRepo.deleteLoggingQueueEntity(
                              twentyBatch.stream().filter { t -> t.id != null }
                                 .map { txz -> txz.id }
                                 .collect(Collectors.toList())
                           )
                           if(loggingQueueRepo.getLoggingQueueEntitiesPost().isNotEmpty()){
                              Result.retry()
                           } else {
                              Result.success()
                           }
                        } else {
                           Result.failure()
                        }
                  } catch (e: Exception) {
                     data = Result.failure()
                  }
               }
         }
      return data
   }
}