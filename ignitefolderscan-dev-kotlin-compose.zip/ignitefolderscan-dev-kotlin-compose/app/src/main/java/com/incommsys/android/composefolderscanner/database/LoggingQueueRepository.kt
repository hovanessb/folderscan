package com.leonell.android.composefolderscanner.database

import com.leonell.android.composefolderscanner.database.dao.LoggingQueueDao
import com.leonell.android.composefolderscanner.database.model.LoggingQueueEntity
import kotlinx.coroutines.flow.*
import javax.inject.Inject

class LoggingQueueRepository @Inject constructor(
   private val loggingQueueDao : LoggingQueueDao
) : LoggingQueueDao {
   fun getLoggingQueueCount(): Flow<Int> = loggingQueueDao.getLoggingQueueEntities().distinctUntilChanged().map {it.count()}
   override fun getLoggingQueueEntities(): Flow<List<LoggingQueueEntity>> = loggingQueueDao.getLoggingQueueEntities()


   override fun getLoggingQueueEntitiesPost(): List<LoggingQueueEntity> = loggingQueueDao.getLoggingQueueEntitiesPost()

   override suspend fun upsertLoggingQueueEntities(entities: List<LoggingQueueEntity>) = loggingQueueDao.upsertLoggingQueueEntities(entities)

   override  fun deleteLoggingQueueEntity(ids: MutableList<Long>) = loggingQueueDao.deleteLoggingQueueEntity(ids)
}