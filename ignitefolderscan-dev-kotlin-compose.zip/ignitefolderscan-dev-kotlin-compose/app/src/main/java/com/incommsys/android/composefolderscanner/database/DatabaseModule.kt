/*
 * Copyright 2022 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.leonell.android.composefolderscanner.database

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase.CONFLICT_IGNORE
import android.util.Log
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.runBlocking
import java.sql.SQLException
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {
    @Provides
    @Singleton
    fun providesFolderScannerDatabase(
        @ApplicationContext context: Context,
    ): FolderScannerDatabase  = Room.databaseBuilder(
            context,
            FolderScannerDatabase::class.java,
            "folder-scanner-database"
        ).createFromAsset("databases/folder-scanner-database").addCallback(object  : RoomDatabase.Callback(){
                override fun onCreate(db: SupportSQLiteDatabase) {
                    super.onCreate(db)
                    runBlocking {
                        db.beginTransaction()
                        try {
                            val rotation = ContentValues().apply{
                                put("id",16266)
                                put ("name","Rotational Shelf")
                                put("original","Cheesecake Bldg CF-19 ROT OUT-1-1")
                                put("spaceA","")
                                put("spaceB","")
                                put("spaceC","")
                                put("filtered",0)
                                put("favorite",1)
                                put("custom",1)
                                put("folderEntityType", "LOCATION")
                            }
                            val annex = ContentValues().apply{
                                put("id",47550)
                                put ("name","ANNEX CF")
                                put("original","ANNEX CF")
                                put("spaceA","")
                                put("spaceB","")
                                put("spaceC","")
                                put("filtered",0)
                                put("favorite",1)
                                put("custom",1)
                                put("folderEntityType", "LOCATION")
                            }
                            val tours = ContentValues().apply{
                                put("id",53686)
                                put ("name","Tour Files")
                                put("original","Cheesecake Bldg CF-13-1-5")
                                put("spaceA","")
                                put("spaceB","")
                                put("spaceC","")
                                put("filtered",0)
                                put("favorite",1)
                                put("custom",1)
                                put("folderEntityType", "LOCATION")
                            }

                            db.insert("folder_location",CONFLICT_IGNORE,rotation)
                            db.insert("folder_location",CONFLICT_IGNORE,annex)
                            db.insert("folder_location",CONFLICT_IGNORE,tours)
                            db.setTransactionSuccessful()
                        } catch (exception : Exception){
                            Log.e("DatabaseModule", exception.stackTrace.toString())
                        } finally {
                            db.endTransaction()
                        }
                    }
                }
            }).build()
    }

