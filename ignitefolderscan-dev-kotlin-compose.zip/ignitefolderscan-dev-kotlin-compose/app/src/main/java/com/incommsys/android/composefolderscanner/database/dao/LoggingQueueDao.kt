/*
 * Copyright 2022 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.leonell.android.composefolderscanner.database.dao

import androidx.room.Dao
import androidx.room.Query
import androidx.room.Upsert
import com.leonell.android.composefolderscanner.database.model.FolderLocationEntity
import com.leonell.android.composefolderscanner.database.model.LoggingQueueEntity
import kotlinx.coroutines.flow.Flow

/**
 * DAO for [FolderLocationEntity] access
 */
@Dao
interface LoggingQueueDao {
    @Query(value = "SELECT * FROM logging_queue order by id")
    fun getLoggingQueueEntities(): Flow<List<LoggingQueueEntity>>

    @Query(value = "SELECT * FROM logging_queue order by id")
    fun getLoggingQueueEntitiesPost(): List<LoggingQueueEntity>

    /**
     * Inserts or updates [entities] in the db under the specified primary keys
     */
    @Upsert
    suspend fun upsertLoggingQueueEntities(entities: List<LoggingQueueEntity>)

    /**
     * Deletes rows in the db matching the specified [ids]
     */
    @Query(
        value = """
                    DELETE FROM logging_queue where id in (:ids)
                """
    )
    fun deleteLoggingQueueEntity(ids: MutableList<Long>)
}
