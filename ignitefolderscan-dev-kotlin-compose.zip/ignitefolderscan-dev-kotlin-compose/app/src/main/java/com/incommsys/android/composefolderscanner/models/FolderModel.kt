package com.leonell.android.composefolderscanner.models

import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf

enum class  FolderEntityType {
   FOLDER, LOCATION, SHELF, UNKNOWN
}


data class FolderModel (
   val id : Number?=0,
   var barcode :  String? = "",
   var givenName : String= "",
   val familyName : String= "",
   val maidenName : String= "",
   val fullName : String? = "",
   val currentLocationId : Number? = 0,
   val currentLocationName : String= "",
   val currentLocationFullName : String= "",
   val shelfA : String = "",
   val shelfB : String = "",
   val shelfC : String = "",
   val currentOrgId : Number = 1,
   val currentOrgName : String = "FSO",
   val currentLocationDate : Number? = 0,
   val currentParentId : Number? = 0,
   val currentParentName : String?= "",
   val folderNumber : String? = "",
   var folderSeriesId : String = "00",
   val folderSeriesName : String = "",
   val folderTypeId: Number =0,
   val folderTypeName : String? = "",
   val fromDate: Number? =0,
   val toDate: Number? = 0,
   val loggedBy : String = "",
   val warehouseLocationId : Number? = 0,
   val warehouseLocationName : String? = "",
   val warehouseParentId : Number? = 0,
   val persId : String? = "",
   var addoId : Number? = 0,
   val folderEntityType : FolderEntityType = FolderEntityType.FOLDER,
   var rssi : MutableState<Float>? = mutableFloatStateOf(0.0F),
   var phase : MutableState<Float>? = mutableFloatStateOf(0.0F),
   var count : MutableState<Float>? = mutableFloatStateOf(0.0F),
)