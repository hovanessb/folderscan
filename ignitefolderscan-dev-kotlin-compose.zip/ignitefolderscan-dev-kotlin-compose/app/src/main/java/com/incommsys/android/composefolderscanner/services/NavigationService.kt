package com.leonell.android.composefolderscanner.services

import androidx.annotation.DrawableRes
import androidx.compose.foundation.layout.RowScope
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import com.leonell.android.ComposeFolderScanner.R
import com.leonell.android.composefolderscanner.ui.deviceScreen
import com.leonell.android.composefolderscanner.ui.locateScreen
import com.leonell.android.composefolderscanner.ui.profileScreen
import com.leonell.android.composefolderscanner.ui.scanNavigationRoute
import com.leonell.android.composefolderscanner.ui.scanScreen
import com.leonell.android.composefolderscanner.ui.viewmodels.ConvergenceHandgunViewModel
import com.leonell.android.composefolderscanner.ui.viewmodels.ScanViewModel
import com.leonell.android.composefolderscanner.ui.viewmodels.TriangulationViewModel
import com.leonell.android.composefolderscanner.ui.writeScreen

/**
 * Now in Android icons. Material icons are [ImageVector]s, custom icons are drawable resource IDs.
 */
object FolderIcons {
   val PROFILE = R.drawable.account_circle
   val BLUETOOTH = R.drawable.bluetooth
   val QR = R.drawable.qr_code_scanner
   val ADD = Icons.Rounded.Add
   val PENCIL =  R.drawable.auto_fix
   val DELETE = Icons.Rounded.Delete
   val LOCATE = R.drawable.token
}

/**
 * A sealed class to make dealing with [ImageVector] and [DrawableRes] icons easier.
 */
sealed class Icon {
   data class ImageVectorIcon(val imageVector: ImageVector) : Icon()
   data class DrawableResourceIcon(@DrawableRes val id: Int) : Icon()
}

/**
 * Type for the top level destinations in the application. Each of these destinations
 * can contain one or more screens (based on the window size). Navigation from one screen to the
 * next within a single destination will be handled directly in composables.
 */
enum class Navigation(
   val selectedIcon: Icon,
   val unselectedIcon: Icon,
   val iconText: String,
   val titleText: String
) {
   PROFILE(
      selectedIcon = Icon.DrawableResourceIcon(FolderIcons.PROFILE),
      unselectedIcon = Icon.DrawableResourceIcon(FolderIcons.PROFILE),
      iconText = "PROFILE",
      titleText = "PROFILE"
   ),
   SCAN(
      selectedIcon = Icon.DrawableResourceIcon(FolderIcons.QR),
      unselectedIcon = Icon.DrawableResourceIcon(FolderIcons.QR),
      iconText = "LOG",
      titleText = "LOG"
   ),
   LOCATE(
      selectedIcon = Icon.DrawableResourceIcon(FolderIcons.LOCATE),
      unselectedIcon = Icon.DrawableResourceIcon(FolderIcons.LOCATE),
      iconText = "LOCATE",
      titleText = "LOCATE"
   ),
   WRITE(
      selectedIcon = Icon.DrawableResourceIcon(FolderIcons.PENCIL),
      unselectedIcon = Icon.DrawableResourceIcon(FolderIcons.PENCIL),
      iconText = "REWRITE",
      titleText = "REWRITE"
   ),
   DEVICES(
      selectedIcon = Icon.DrawableResourceIcon(FolderIcons.BLUETOOTH),
      unselectedIcon = Icon.DrawableResourceIcon(FolderIcons.BLUETOOTH),
      iconText = "DEVICES",
      titleText = "DEVICES"
   )
}

@Composable
fun FolderNavHost(
   navController: NavHostController,
   modifier: Modifier = Modifier,
   startDestination: String = scanNavigationRoute,
   scanModel: ScanViewModel = hiltViewModel(),
   convergenceModel: ConvergenceHandgunViewModel = hiltViewModel(),
   traingulationModel: TriangulationViewModel = hiltViewModel(),
   simpleMode: Boolean
) {
   NavHost(
      navController = navController,
      startDestination = startDestination,
      modifier = modifier,
   ) {
      profileScreen(navController=navController,scanModel = scanModel)
      scanScreen(scanModel = scanModel,convergenceModel=convergenceModel)
      writeScreen(scanModel = scanModel,convergenceModel=convergenceModel)
      locateScreen(scanModel = scanModel,convergenceModel=convergenceModel, triangulationViewModel =traingulationModel)
      deviceScreen(convergenceModel = convergenceModel)
   }
}

@Composable
fun RowScope.FolderNavigationBarItem(
   selected: Boolean,
   onClick: () -> Unit,
   icon: @Composable () -> Unit,
   modifier: Modifier = Modifier,
   selectedIcon: @Composable () -> Unit = icon,
   enabled: Boolean = true,
   label: @Composable (() -> Unit)? = null,
   alwaysShowLabel: Boolean = true
) {
   NavigationBarItem(
      selected = selected,
      onClick = onClick,
      icon = if (selected) selectedIcon else icon,
      modifier = modifier,
      enabled = enabled,
      label = label,
      alwaysShowLabel = alwaysShowLabel
   )
}

/**
 * Now in Android navigation bar with content slot. Wraps Material 3 [NavigationBar].
 *
 * @param modifier Modifier to be applied to the navigation bar.
 * @param content Destinations inside the navigation bar. This should contain multiple
 * [NavigationBarItem]s.
 */
@Composable
fun FolderNavigationBar(
   modifier: Modifier = Modifier,
   content: @Composable RowScope.() -> Unit
) {
   NavigationBar(
      modifier = modifier,
      tonalElevation = 5.dp,
      content = content
   )
}
