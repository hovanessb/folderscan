package com.leonell.android.composefolderscanner.models

const val currentAuthToken = "Authorization: Basic "
const val projectAuthToken = "Authorization: Basic "
enum class  LoginStatus {
    IDLE,PENDING, DONE, ERROR
}

class AuthTokenModel (
    val id : String,
    val isAuthenticated : Boolean,
    val loginStatus : LoginStatus
)