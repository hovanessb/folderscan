package com.leonell.android.composefolderscanner.ui.screens

import android.util.Log
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.absoluteOffset
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Divider
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.leonell.android.composefolderscanner.models.FolderModel
import com.leonell.android.composefolderscanner.services.FolderIcons
import com.leonell.android.composefolderscanner.services.PersonRestInterface
import com.leonell.android.composefolderscanner.services.WebApi
import com.leonell.android.composefolderscanner.ui.components.Empty
import com.leonell.android.composefolderscanner.ui.components.Thermometer
import com.leonell.android.composefolderscanner.ui.theme.IgniteFolderScannerTheme
import com.leonell.android.composefolderscanner.ui.viewmodels.ConvergenceHandgunState
import com.leonell.android.composefolderscanner.ui.viewmodels.ConvergenceHandgunViewModel
import com.leonell.android.composefolderscanner.ui.viewmodels.ScanViewModel
import com.leonell.android.composefolderscanner.ui.viewmodels.TriangulationViewModel
import kotlinx.coroutines.delay

@Composable
internal fun LocateRoute(
   barcodeId: String? = "",
   scanModel: ScanViewModel = hiltViewModel(),
   convergenceModel: ConvergenceHandgunViewModel = hiltViewModel(),
   triangulationModel: TriangulationViewModel = hiltViewModel()
) {
      LocateScreen( barcodeIdSeries=barcodeId,scanModel=scanModel, convergenceModel=convergenceModel, triangulationModel = triangulationModel)
}

@Composable
internal fun LocateScreen(
   barcodeIdSeries: String?,
   scanModel: ScanViewModel,
   convergenceModel : ConvergenceHandgunViewModel,
   triangulationModel : TriangulationViewModel
) {
   val labelMin = -90
   val labelMax = -10
   val barMax = 1.0f
   val snackbarHostState = remember { SnackbarHostState() }
   val releasedScanning = remember { mutableStateOf(false) }
   val sessionString = remember { mutableStateOf("") }
   val connectedGun by convergenceModel.uiState.collectAsStateWithLifecycle()
   val webApi : PersonRestInterface = WebApi().getPersonWebService()
   val barcodeScanData by scanModel.uiState.collectAsStateWithLifecycle()
   val sensorData by triangulationModel.sensorData.collectAsStateWithLifecycle()
   val geigerFolder = remember{mutableStateOf(FolderModel())}
   val geigerFolderRssi = remember{ mutableFloatStateOf(0.00f) }
   val duration = remember{ mutableIntStateOf(5) }
   val rotating = remember{ mutableFloatStateOf(0.0f) }
   val geigerFolderPhase = remember{mutableFloatStateOf(0.00f)}
   val name = remember { mutableStateOf("") }

   LaunchedEffect(key1 = barcodeScanData.barcode) {
      try {
         if(barcodeScanData.barcode != null){
            val person = webApi.getPersonByBarcode(barcodeScanData.barcode!!.barcodeId)
            geigerFolder.value.givenName = person.fullName!!
            geigerFolder.value.addoId = person.addoId!!
            geigerFolder.value.barcode = barcodeScanData.barcode!!.barcodeId
            name.value = geigerFolder.value.givenName + " #" + geigerFolder.value.addoId
            convergenceModel.startSearch(barcodeScanData.barcode!!.rawRead!!)
         }
      } catch (myException: Exception) {
         Log.e("LocateScreen", myException.stackTraceToString())
      }
   }
   DisposableEffect(key1 = convergenceModel.getProfile()){
      onDispose{
         convergenceModel.setScanModeDefaults()
      }
   }
   LaunchedEffect(key1 = barcodeIdSeries) {
      try {
         if(!barcodeIdSeries.isNullOrEmpty()){
            val barcode = barcodeIdSeries.split("-")[0]
            val seriesId = barcodeIdSeries.split("-")[1]
            val person = webApi.getPersonByBarcode(barcode)
            geigerFolder.value.givenName = person.fullName!!
            geigerFolder.value.addoId = person.addoId!!
            geigerFolder.value.barcode = barcode
            geigerFolder.value.folderSeriesId = seriesId
            name.value = geigerFolder.value.givenName + " #" + geigerFolder.value.addoId
            convergenceModel.startSearch(barcodeIdSeries.toByteArray(Charsets.US_ASCII))
         }
      } catch (myException: Exception) {
         Log.e("LocateScreen", myException.stackTraceToString())
      }
   }


   LaunchedEffect(key1 = geigerFolderRssi.floatValue) {
      if(geigerFolderRssi.floatValue > 0.0f){
         delay(250)
         geigerFolderRssi.floatValue = geigerFolderRssi.floatValue - 0.20f
      } else {
         geigerFolderRssi.floatValue = 0.0f
      }
   }

   LaunchedEffect(key1 = barcodeScanData.barcode?.barcodeId){
      try {
         if   (barcodeScanData.barcode != null
            && !barcodeScanData.geigerFolders.stream().anyMatch { barcodeScanData.barcode!!.barcodeId == it.barcodeId }
            && barcodeScanData.barcode!!.barcodeId.length >= 12) {
            val person = webApi.getPersonByBarcode(barcodeScanData.barcode!!.barcodeId)
            geigerFolder.value.givenName  = person.fullName!!
            geigerFolder.value.addoId  = person.addoId
            geigerFolder.value.barcode  = barcodeScanData.barcode!!.barcodeId
            name.value = geigerFolder.value.givenName + " #" + geigerFolder.value.addoId
         }
      } catch(myException : Exception) {
         Log.e("LocateScreen",myException.stackTraceToString())
      }
   }

   when(connectedGun){
      is ConvergenceHandgunState.Scanning -> if ((connectedGun as ConvergenceHandgunState.Scanning).rfidData != null){
         val rfidData = (connectedGun as ConvergenceHandgunState.Scanning).rfidData
         if (rfidData?.rawRead != null) {
            sensorData?.let {
               it.session = sessionString.value
               triangulationModel.saveRfidSensorData(it, rfidData)
            }

            val dbConstant = 106.98
            val rssi = rfidData.rssi + dbConstant

            geigerFolderRssi.floatValue =
               (barMax * (rssi - labelMin - dbConstant) / (labelMax - labelMin)).toFloat()

            if (geigerFolderRssi.floatValue < 0) {
               geigerFolderRssi.floatValue = 0.0F
            }

            if (geigerFolderRssi.floatValue > barMax) {
               geigerFolderRssi.floatValue = barMax
            }
         }
      }
      else -> {}
   }

      Column {
         Scaffold(floatingActionButton = {
            if(geigerFolder.value.givenName != "" || connectedGun is ConvergenceHandgunState.Scanning ){
               FloatingActionButton(onClick = {
                  scanModel.clearGeiger()
                  triangulationModel.deleteSessions()
                  name.value = ""
               }) {
                  Icon(FolderIcons.DELETE, "Delete")
               }
            }},
            snackbarHost = { SnackbarHost(snackbarHostState) },
            content= {
               body(
                  it,
                  geigerFolderRssi.floatValue,
                  name.value,
                  releasedScanning.value
               )
            })
      }
}
@Composable
private fun body(paddingValues: PaddingValues, percentState: Float,
                 name: String, releasedScanning: Boolean){
   Column(
      modifier = Modifier
         .fillMaxSize()
         .padding(paddingValues),
      verticalArrangement = Arrangement.Center,
      horizontalAlignment = Alignment.CenterHorizontally
   ) {
      Column (modifier= Modifier
         .padding(4.dp)
         .fillMaxWidth() ,
         horizontalAlignment = Alignment.CenterHorizontally){
         Text("SEARCH FOR RFIDS",modifier=Modifier.padding(16.dp), style = MaterialTheme.typography.titleLarge)
      }
      Divider(modifier = Modifier.padding(horizontal = 20.dp))
      Box(
            modifier = Modifier
               .weight(1f)
               .fillMaxSize()
      ) {
         if(name != ""){
            Text( text = name + " - " +(percentState * 100).toInt().toString()+"%",
                  modifier = Modifier
                     .fillMaxSize()
                     .align(Alignment.Center),
                  color=MaterialTheme.colorScheme.tertiary,
                  textAlign = TextAlign.Center)
            if(releasedScanning){
               Empty(Modifier,"BEGIN SEARCH")
            }
            Thermometer(modifier= Modifier
               .padding(20.dp)
               .fillMaxSize(),
               percentState,
               triggered = !releasedScanning)
         } else {
            Empty(Modifier)
         }
      }
   }
}
@Preview(showBackground = true)
@Composable
private fun previewLocateScreen(){
   IgniteFolderScannerTheme {
      Text( text = (0.75 * 100).toInt().toString(),
         modifier = Modifier
            .fillMaxSize()
            .absoluteOffset(y = 450.dp),
         color=MaterialTheme.colorScheme.background,
         textAlign = TextAlign.Center)
      val geigerFolderRssi = rememberSaveable{ mutableFloatStateOf(0.99f) }
      body(PaddingValues(16.dp), geigerFolderRssi.floatValue, "Test Name", true)
   }
}