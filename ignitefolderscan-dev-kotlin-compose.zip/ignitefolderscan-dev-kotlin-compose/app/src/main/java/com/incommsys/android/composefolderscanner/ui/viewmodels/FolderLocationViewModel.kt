package com.leonell.android.composefolderscanner.ui.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.leonell.android.composefolderscanner.database.FolderLocationRepository
import com.leonell.android.composefolderscanner.database.model.asExternalModel
import com.leonell.android.composefolderscanner.models.BarcodeEntityModel
import com.leonell.android.composefolderscanner.models.ScanModel
import com.leonell.android.composefolderscanner.models.asDatabaseModel
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.stream.Collectors
import javax.inject.Inject


private fun folderLocationUiState(): FolderLocationUiState {
   return FolderLocationUiState.Loading
}

sealed interface FolderLocationUiState {
   object Success : FolderLocationUiState
   data class Error(val message : String) : FolderLocationUiState
   object Loading : FolderLocationUiState
}

data class CurrentLocationState (
   val location: BarcodeEntityModel.FolderLocation?,
   val currentPerson : BarcodeEntityModel.Person?,
   val search  : String = ""
)

@HiltViewModel
class FolderLocationViewModel @Inject constructor(
   private val folderLocationRepo : FolderLocationRepository
): ViewModel(){
   private val mutableUiState = MutableStateFlow(folderLocationUiState())
   val uiState : StateFlow<FolderLocationUiState> = mutableUiState.asStateFlow()
   private val currentLocationData = MutableStateFlow(CurrentLocationState(null,  null))
   val currentLocationState : StateFlow<CurrentLocationState> = currentLocationData.asStateFlow()
   var getLocations  : Flow<List<BarcodeEntityModel.FolderLocation>> = folderLocationRepo
         .getFolderLocationEntities()
         .map {
            it.stream().filter {
               item -> if (currentLocationState.value.search.isNotBlank()){
                  item.name.contains(currentLocationState.value.search)
               } else {
                  true
               }
            }.map {itx-> itx.asExternalModel()}.collect(Collectors.toList())}
         .distinctUntilChanged()
         .transform {
            emit(it)
            if(it.isNotEmpty()){
               mutableUiState.update { FolderLocationUiState.Success}
            }
         }
   init {
      viewModelScope.launch(Dispatchers.IO){
         // Pull from REST server if the local DB is empty
         folderLocationRepo.getFolderLocationsREST()
      }
   }

   fun setLocation(folder: BarcodeEntityModel.FolderLocation?) = currentLocationData.update {currentState-> currentState.copy(location = folder)}


   fun saveLocation(aLocation: BarcodeEntityModel.FolderLocation){
      viewModelScope.launch(Dispatchers.IO) {
         folderLocationRepo.upsertFolderLocations(listOf( aLocation.asDatabaseModel()))
      }
   }

   fun delete(aLocation: BarcodeEntityModel.FolderLocation){
      viewModelScope.launch(Dispatchers.IO) {
         if(aLocation.custom){
            folderLocationRepo.deleteFolderLocations(listOf( aLocation.id.toString()))
         }
      }
   }

   fun search(aLocation: String){
      currentLocationData.update {currentState->
         currentState.copy(search = aLocation)
      }
   }

   fun lookup(aBarcode: ScanModel) {
      viewModelScope.launch(Dispatchers.Default) {
         val result = folderLocationRepo.lookup(aBarcode)
         if (result != null){
            when (result.entityObject){
               is BarcodeEntityModel.FolderLocation -> {
                  currentLocationData.update {currentState->
                     currentState.copy(location = result.entityObject as BarcodeEntityModel.FolderLocation)
                  }
               }
               is BarcodeEntityModel.Person -> {
                  currentLocationData.update {currentState->
                     currentState.copy(currentPerson = result.entityObject as BarcodeEntityModel.Person)
                  }
               }
               else -> {}
            }
         }
      }
   }

   fun logOneLocation(aBarcode: String, aLocationId : Long) {
      viewModelScope.launch(Dispatchers.Default) {
         val code = folderLocationRepo.logOneLocation(aBarcode, aLocationId)
         if(code == 401) {
            mutableUiState.update { FolderLocationUiState.Error(message = "Bad Credentials.") }
         } else if (code != 200) {
            mutableUiState.update { FolderLocationUiState.Error(message = "There was a problem logging the folders.") }
         } else {
            mutableUiState.update { FolderLocationUiState.Success }
         }
      }
   }

}