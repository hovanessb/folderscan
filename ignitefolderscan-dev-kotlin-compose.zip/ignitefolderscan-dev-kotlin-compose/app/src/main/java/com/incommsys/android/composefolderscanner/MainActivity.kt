package com.leonell.android.composefolderscanner
 import android.annotation.SuppressLint
 import android.content.Intent
 import android.os.Bundle
 import android.util.Log
 import androidx.activity.ComponentActivity
 import androidx.activity.compose.setContent
 import androidx.activity.viewModels
 import androidx.compose.runtime.LaunchedEffect
 import androidx.compose.runtime.mutableStateOf
 import androidx.compose.runtime.remember
 import androidx.core.text.isDigitsOnly
 import androidx.core.util.Consumer
 import com.leonell.android.composefolderscanner.models.ScanModel
 import com.leonell.android.composefolderscanner.services.*
 import com.leonell.android.composefolderscanner.ui.FolderApp
 import com.leonell.android.composefolderscanner.ui.rememberFolderAppState
 import com.leonell.android.composefolderscanner.ui.theme.IgniteFolderScannerTheme
 import com.leonell.android.composefolderscanner.ui.viewmodels.ConvergenceHandgunViewModel
 import com.leonell.android.composefolderscanner.ui.viewmodels.ScanViewModel
 import com.leonell.android.composefolderscanner.ui.viewmodels.TriangulationViewModel
 import dagger.hilt.android.AndroidEntryPoint
 import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

   @Inject
   lateinit var networkMonitor: NetworkMonitor

   private val scanModel: ScanViewModel by viewModels()
   private val convergenceModel : ConvergenceHandgunViewModel by viewModels()
   private val triangulationModel : TriangulationViewModel by viewModels()

   @SuppressLint("MissingPermission", "UnusedMaterialScaffoldPaddingParameter")
   override fun onCreate(savedInstanceState: Bundle?) {
      super.onCreate(savedInstanceState)

      setContent {
         val appState = rememberFolderAppState( networkMonitor = networkMonitor)
         val result = remember { mutableStateOf<Int?>(100) }

         LaunchedEffect(key1 = result.value) {
            peekAvailableContext()?.let { it ->
               convergenceModel.startBleLibrary(it)
               DataWedgeService.createDWProfile(it)
               triangulationModel.getSenses(it)
               val listener = Consumer<Intent>{ intent ->
                  val decodedData : String? = intent?.getStringExtra("com.symbol.datawedge.data_string")
                  try {
                     decodedData?.isDigitsOnly()?.let { it1 -> assert(it1) }
                     decodedData?.let {it1 ->
                        scanModel.setBarcodeScan(ScanModel(
                           barcodeId =it1,
                           seriesId =null,
                           rawRead = decodedData.toByteArray(Charsets.US_ASCII)))}
                  } catch (_: Exception){
                     Log.w("MainActivity", "Scanning non-digit barcodes...")
                  }
               }
               addOnNewIntentListener(listener)
            }
         }

         IgniteFolderScannerTheme(useDarkTheme = false, content = {
            FolderApp(
               appState = appState,
               scanModel=scanModel,
               convergenceModel=convergenceModel,
               triangulationModel = triangulationModel
            )
         })
      }



   }
}