# Hardware Requirements
This require Android 10 minimally to run. It will work well with the following devices:

1. Zebra TC10 Handheld Barcode [PDF](tc21-tc26-a10-prg-en.pdf.pdf)
2. Any Android 10 devices with a Camera to scan barcodes with

**RFID Scanner**
This application only supports the Convergence Systems CS108 [PDF](cs108.pdf)