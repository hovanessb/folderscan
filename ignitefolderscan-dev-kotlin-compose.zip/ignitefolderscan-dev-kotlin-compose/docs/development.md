## Kotlin Jetpack Compose

The project is built using the Kotlin Jetpack Compose framework. 

**Requirements**
Ensure you have the following:

1. AndroidSDK30.0.2,AndroidSDK30.0.3,AndroidSDK30.0.3 
2. javasdk 11
3. ndk 24.0.8215888"


**Recommended programs**
 - `adb` for debugging
 - Android Studio 